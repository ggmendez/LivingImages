describe('pixi/loaders/SpriteSheetLoader', function () {
    'use strict';

    var expect = chai.expect;
    var SpriteSheetLoader = PIXI.SpriteSheetLoader;

    it('Module exists', function () {
        expect(SpriteSheetLoader).to.be.a('function');
    });
});
