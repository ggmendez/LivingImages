describe('pixi/loaders/ImageLoader', function () {
    'use strict';

    var expect = chai.expect;
    var ImageLoader = PIXI.ImageLoader;

    it('Module exists', function () {
        expect(ImageLoader).to.be.a('function');
    });
});
