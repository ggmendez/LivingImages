describe('pixi/text/BitmapText', function () {
    'use strict';

    var expect = chai.expect;
    var BitmapText = PIXI.BitmapText;

    it('Module exists', function () {
        expect(BitmapText).to.be.a('function');
    });
});
